basic pdfminer:		- This miner counts all words across multiple pdfs in one file location and spits out the word count for each word in every pdf file.
	word counter	- Useful in language and data analysis projects.

               		- Make sure all files are placed in one folder, follow all '<insert path>' instructions in the code.

				using pip:
				>  pip install pandas
				>  pip install pdfminer.six

Report Generator 	- Used to generate a small report to used for parents evenings, based off three tests but it can easily be
                   	  expanded to include more
                 	- Demonstrates my ability to manipulate and utilise data within Python
                 	- Parts of the code are AI generated as I was testing out the abilities of multiple AIs

Korea VECM.do 		- A Vector Error Correction Model coded as part of my master's dissertation. Using Korea Data 1.dta, it 
                 	  fits the data to a VECM in a structural way based on economic reasoning in an attempt to establish a 
                	  link between Financial Regulation scores and and consumption volatility  