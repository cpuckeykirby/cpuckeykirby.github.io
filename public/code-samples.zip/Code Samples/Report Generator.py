import os
import glob
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import pdfkit
import io
import base64

# Parameters
CSV_FILENAME = "C:/Users/run29/Documents/English School of Mongolia/Parents Evening/Grade_8_Sheet.csv"
REPORTS_DIR = "C:/Users/run29/Documents/English School of Mongolia/Parents Evening/reports_8stand"

# Create output directory if it doesn't exist
os.makedirs(REPORTS_DIR, exist_ok=True)

# Read the CSV file into a DataFrame
df = pd.read_csv(CSV_FILENAME)

# Compute class-wide statistics for "Current Overall"
overall_scores = df["Current Overall"]
class_mean = overall_scores.mean()
class_median = overall_scores.median()
class_std = overall_scores.std()

# wkhtmltopdf configuration (adjust path if necessary)
config = pdfkit.configuration(wkhtmltopdf="C:/Program Files/wkhtmltopdf/bin/wkhtmltopdf.exe") # Replace with your path

# Loop over each student to generate individual HTML reports and plots
all_html_content = ""

for idx, row in df.iterrows():
    first_name = row["First Name"]
    last_name = row["Last Name"]
    test_scores = [row["Test 1"], row["Test 2"], row["Test 3"]]
    overall = row["Current Overall"]
    comments = row["Detailed Comments"]

    # Create performance comment relative to class mean
    if overall > class_mean:
        performance = "above"
    elif overall < class_mean:
        performance = "below"
    else:
        performance = "at"

    # -----------------------------
    # Plot 1: Class distribution of Current Overall
    plt.figure(figsize=(8, 4))
    sns.histplot(overall_scores, bins=20, kde=True, color='skyblue')
    plt.axvline(overall, color='red', linestyle='--',
                label=f"{first_name} {last_name}'s Score: {overall}")
    plt.xlabel("Current Overall")
    plt.ylabel("Frequency")
    plt.title("Class Distribution of Current Overall")
    plt.legend()
    distribution_stream = io.BytesIO()
    plt.tight_layout()
    plt.savefig(distribution_stream, format='png')
    plt.close()
    distribution_base64 = base64.b64encode(distribution_stream.getvalue()).decode('utf-8')

    # -----------------------------
    # Plot 2: Test Scores Trend (Line Plot)
    plt.figure(figsize=(6, 4))
    tests = ["Test 1", "Test 2", "Test 3"]
    plt.plot(tests, test_scores, marker='o', linestyle='-', color='green')
    plt.ylim(0, 100)
    plt.xlabel("Test")
    plt.ylabel("Score")
    plt.title("Test Scores Trend")
    trend_stream = io.BytesIO()
    plt.tight_layout()
    plt.savefig(trend_stream, format='png')
    plt.close()
    trend_base64 = base64.b64encode(trend_stream.getvalue()).decode('utf-8')

    # -----------------------------
    # Generate individual HTML report for the student
    all_html_content += f"""
    <div style='page-break-after: always;'>
        <h1>Report for {first_name} {last_name}</h1>
        <h2>Student Details</h2>
        <p><strong>Test Scores:</strong> Test 1: {row['Test 1']}, Test 2: {row['Test 2']}, Test 3: {row['Test 3']}</p>
        <p><strong>Current Overall:</strong> {overall}</p>
        <p><strong>Performance:</strong> The student's overall score is {performance} the class average of {class_mean:.2f}.</p>
        <h2>Performance Graphs</h2>
        <div style='display: flex; justify-content: center; gap: 20px;'>
            <img src='data:image/png;base64,{distribution_base64}' alt='Distribution Plot' style='width: auto; max-width: 380px;'>
            <img src='data:image/png;base64,{trend_base64}' alt='Test Scores Trend Plot' style='width: auto; max-width: 380px;'>
        </div>
        <h2>Comments</h2>
        <p>{comments}</p>
        <h2>Class Statistics</h2>
        <p>Mean: {class_mean:.2f}, Median: {class_median:.2f}, Standard Deviation: {class_std:.2f}</p>
    </div>
    """

print(f"Individual reports have been generated in memory.")

# -----------------------------
# Create the combined HTML file with common header, styling, and page breaks
html_content = f"""
<html><head><meta charset='utf-8'><title>Combined Report</title>
<style>
    body {{ font-family: Arial, sans-serif; margin: 20px; text-align: center; background-color: #f9f9f9; }}
    .content {{ max-width: 1000px; margin: auto; background: #fff; padding: 20px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }}
    section {{ margin-bottom: 40px; padding: 10px; border-bottom: 1px solid #ccc; page-break-after: always; }}
    h2 {{ color: #333; }}
</style>
</head><body><div class='content'><h1>Combined Report</h1>{all_html_content}</div></body></html>
"""

pdf_combined_filename = os.path.join(REPORTS_DIR, "combined_report.pdf")
pdfkit.from_string(html_content, pdf_combined_filename, configuration=config)

print(f"Combined PDF report saved as {pdf_combined_filename}")